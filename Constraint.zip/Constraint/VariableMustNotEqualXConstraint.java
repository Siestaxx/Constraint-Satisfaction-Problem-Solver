package Constraint;

import Variable.Variable;

public final class VariableMustNotEqualXConstraint extends UnaryConstraint {
//use to get "!=" constraint in the map problem and check consistency
    private final int X;

    public VariableMustNotEqualXConstraint(Variable x, int X) {
        super(x);
        this.X = X;
    }

    @Override
    public boolean isConsistency() {
        if (!x.isAssignment())
            return true;
        return x.getValue() != X;

    }
}