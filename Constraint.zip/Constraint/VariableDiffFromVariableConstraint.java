package Constraint;

import Variable.Variable;

public final class VariableDiffFromVariableConstraint extends BinaryConstraint {


    public VariableDiffFromVariableConstraint(Variable x, Variable y) {
        super(x, y);
    }
//used in map, the adjacent two should be different from each other
//also used in queen,  to check whether two queens are in the same row.

    @Override
    public boolean isConsistency() {
        if (!x.isAssignment() || !y.isAssignment())
            return true;
        return x.getValue() != y.getValue();
    }
}