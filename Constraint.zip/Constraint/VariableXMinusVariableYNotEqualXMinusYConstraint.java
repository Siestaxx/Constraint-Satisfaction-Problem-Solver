package Constraint;

import Variable.Variable;
//Used in queen problem. This comment is used to determine whether two queens are on the same diagonal lines
public final class VariableXMinusVariableYNotEqualXMinusYConstraint extends BinaryConstraint {


    private final int idx, idy;

    //constructor,idx and idy is the column number for each queen
    public VariableXMinusVariableYNotEqualXMinusYConstraint(Variable x, int idx, Variable y, int idy) {
        super(x, y);
        this.idx = idx;
        this.idy = idy;
    }

    @Override
    public boolean isConsistency() {
        if (!x.isAssignment() || !y.isAssignment())
            return true;
      //if difference between column numbers is equal to difference between values, it will be in the same diagonal line. 
        return Math.abs(x.getValue() - y.getValue()) != Math.abs(idx - idy); 
    }
}
