package Problem;

import Constraint.IConstraint;
import Solver.ISolver;
import Solver.Solver;
import Variable.Variable;
import Variable.Solution;

import java.util.ArrayList;

public abstract class Problem implements IProblem {


    protected ArrayList<Variable> vars;
    protected ArrayList<IConstraint> constraints;

    protected String instanceFileName;

    protected ISolver solver;

    protected ArrayList<Solution> solutions;


    public Problem() {
        vars = new ArrayList<>();
        constraints = new ArrayList<>();
        solutions = new ArrayList<>();
        solver = new Solver(this);

    }

    public Problem(String instanceFileName) {
        this();
        this.instanceFileName = instanceFileName;

    }
//add solutions, variables, constraints 
    public void addSolution() {
        solutions.add(new Solution(vars));
    }

    public void addVar(Variable v) {
        vars.add(v);
    }

    public void addConstraint(IConstraint c) {
        constraints.add(c);
    }
//get variable and constraints
    public ArrayList<Variable> getVars() {
        return vars;
    }

    public ArrayList<IConstraint> getConstraints() {
        return constraints;
    }
//use backtrack to solve
    @Override
    public void solve() {
        solver.solve();
    }

//print solution if no solution then print no solution
    @Override
    public void printSolution() {
        if (solutions.size() == 0)
            System.out.println("no solution");
        for (Solution s : solutions) {
            System.out.println(s);
        }

    }
}
