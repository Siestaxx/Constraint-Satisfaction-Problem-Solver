package Problem;

import Constraint.VariableDiffFromVariableConstraint;
import Constraint.VariableMustEqualXConstraint;
import Constraint.VariableMustNotEqualXConstraint;
import Variable.Variable;
import Variable.Domain;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

public final class MapColoringProblem extends Problem {


    final String ProblemType = "map";
    String descriptionOrTitle;

    public MapColoringProblem(String fileName) {
        super(fileName);
        readInstance();
    }

    @Override
    public void readInstance() {
        try {
            BufferedReader in = new BufferedReader(new FileReader(instanceFileName));


            String str = in.readLine();
            descriptionOrTitle = in.readLine();
// for Region names Ri separated by spaces
            String RegionNames = in.readLine();
//the blank space seperate each state
            String[] regionNamesSplit = RegionNames.split(" ");
            HashMap<String, Variable> VariableByName = new HashMap<>();
            for (String s : regionNamesSplit) { //add variables ( each state as variable and there is space between each state)
                Variable v = new Variable(s);
                VariableByName.put(s, v);
                addVar(v);
            }
            for (int i = 0; i < regionNamesSplit.length; i++) {
                String line = in.readLine();
//for folloing lines with a state and its adjacent state seperated by the blank
                String[] lineSplit = line.split(" ");
                Variable current = VariableByName.get(lineSplit[0]);
                for (int j = 1; j < lineSplit.length; j++) {
                    Variable v = VariableByName.get(lineSplit[j]);
                    if (v == null) {
                        System.err.println("no such a variable named " + lineSplit[j] + "!!!");
                        System.exit(-1);
                    }
                    //apply that two regions adjacent to each other must be different constraint
                    addConstraint(new VariableDiffFromVariableConstraint(current, v));
                }
            }
    //for one line listing the possible colors, separated by spaces
            String valueLine = in.readLine();
            String[] valueLineSplit = valueLine.split(" ");
            HashMap<String, Integer> ValueByName = new HashMap<>();
            for (int i = 0; i < valueLineSplit.length; i++) {
                ValueByName.put(valueLineSplit[i], i);
            }
    //they are the domain of the problem
            for (Variable var : vars) {
                Domain d = new Domain(valueLineSplit);
                var.setDomain(d);
            }
            do {//for constraint lines in the file
                String remain = in.readLine();
                if (remain == null || remain.isEmpty())
                    break;
                String[] remainSplit = remain.split(" ");
                if (remainSplit.length != 3)
                    continue;
                // if we find a = in a line of the file, then apply the VariableMustEqualXConstraint
                if (remainSplit[1].equals("=")) {
                    Variable v = VariableByName.get(remainSplit[0]);
//add that constraint
                    addConstraint(new VariableMustEqualXConstraint(v, ValueByName.get(remainSplit[2])));
// if we find a != in a line of the file, then apply the VariableMustNotEqualXConstraint
                } else if (remainSplit[1].equals("!=")) {
                    Variable v = VariableByName.get(remainSplit[0]);
                    //add that constraint
                    addConstraint(new VariableMustNotEqualXConstraint(v, ValueByName.get(remainSplit[2])));
                }

            } while (true);

            in.close();

        } catch (Exception e) {
            System.err.println("open file " + instanceFileName + " error!!!");
            System.exit(-1);
        }

    }
}
