package Problem;

public interface IProblem {

     void readInstance();

     void solve();

     void printSolution();



}
