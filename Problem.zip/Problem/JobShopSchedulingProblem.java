package Problem;


import Constraint.CapacityConstraint;
import Constraint.PrecedenceConstraint;
import Variable.Variable;
import Variable.Domain;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

public final class JobShopSchedulingProblem extends Problem {

    final String ProblemType = "jobshop";
    String descriptionOrTitle;

    int TMax;
    public JobShopSchedulingProblem(String fileName) {
        super(fileName);
        readInstance();
    }
//read the file and determine type of contraints
    @Override
    public void readInstance() {


        try {
            BufferedReader in = new BufferedReader(new FileReader(instanceFileName));
//if doesnt have first line of jobshop then exit
            String str = in.readLine();
            if (!ProblemType.equals(str)) {
                System.err.println("Problem type error, it should be " + ProblemType);
                System.exit(-1);
            }
//if doesnt have description line then exit
            descriptionOrTitle = in.readLine();
//these are for the task names on line 3 sperated by a blank
            String TasksNames = in.readLine();
//read for each task ti, a line with ti followed by its duration di, separated by a space
            String[] TasksNamesSplit = TasksNames.split(" ");
        // for the job name
            HashMap<String, Integer> DurationByName = new HashMap<>();
            for (int i = 0; i < TasksNamesSplit.length; i++) {
                String line = in.readLine();
                String[] lineSplit = line.split(" ");
                if (lineSplit.length != 2) {
                    System.err.println("format error in [" + line + "]!!!");
                    System.exit(-1);
                }
        // for the corresponding time needed
                int duration = 0;
                try {
                    duration = Integer.parseInt(lineSplit[1]);
                } catch (NumberFormatException e) {
                    System.err.println("parse duration " + lineSplit[1] + " into integer error!!!");
                }
                DurationByName.put(lineSplit[0], duration);
            }
//reading the line of Tmax which is a number
            String TMaxString = in.readLine();
            try {
                TMax = Integer.parseInt(TMaxString);
            } catch (NumberFormatException e) {
                System.err.println("parse TMax" + TMaxString + " into integer error!!!");
            }
            //because the max time can not exceed Tmax
            HashMap<String, Variable> VariableByName = new HashMap<>();
            for (String s : TasksNamesSplit) { //add variables
                Variable v = new Variable(s,new Domain(0,TMax));//  JobShopSchedulingVariable(s, new Domain(0, TMax));
                VariableByName.put(s, v);
                addVar(v);
            }

            do {//these are for remaining lines are binary constraints of the form “ti before tj ” or  “ti disjoint tj ”
                String remain = in.readLine();
                //if doesnt exist then exit
                if (remain == null || remain.isEmpty())
                    break;
                String[] remainSplit = remain.split(" ");
                if (remainSplit.length != 3)
                    continue;
                //if there is 'before' then use precedance constraint
                if (remainSplit[1].equals("before")) {
                    Variable v1 = VariableByName.get(remainSplit[0]);
                    Variable v2 = VariableByName.get(remainSplit[2]);
                    addConstraint(new PrecedenceConstraint(v1, v2, DurationByName.get(remainSplit[0])));
//if there is 'disjoint' then use capacity constraint
                } else if (remainSplit[1].equals("disjoint")) {
                    Variable v1 = VariableByName.get(remainSplit[0]);
                    Variable v2 = VariableByName.get(remainSplit[2]);
                    addConstraint(new CapacityConstraint(v1, DurationByName.get(remainSplit[0]), v2, DurationByName.get(remainSplit[2])));
                }

            } while (true);
            in.close();
        } catch (Exception e) {
            System.err.println("open file " + instanceFileName + " error!!!");
            System.exit(-1);
        }

    }
}

