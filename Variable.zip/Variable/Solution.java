package Variable;

import java.util.ArrayList;

public final class Solution {

    ArrayList<Variable> variables;
    ArrayList<String> values;
//solution set with varible correspodning the value of it
    public Solution(ArrayList<Variable> variables) {
        this.variables = variables;
        values = new ArrayList<>();
        for (Variable v : variables)
            values.add(v.getValueName());
    }
//gets the solution that assign each variable with a value in the domain, a blank is in between
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < variables.size(); i++) {
            stringBuilder.append(variables.get(i).getName()).append(" ").append(values.get(i)).append("\n");
        }
        return stringBuilder.toString();

    }
}
