package Variable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Domain implements Iterable<Value> {
//domian class for the csp framework
    private final ArrayList<Value> values;

//iterate the value to get domain
    private Iterator<Value> it;

    class DomainIterator implements Iterator<Value> {

        int pointer = 0;
        @Override
        public boolean hasNext() {
            return pointer < values.size();
        }

        @Override
        public Value next() {
            Value value = values.get(pointer);
            pointer++;
            return value;
        }
    }
//create domain arryalist and can iterate, also construct different domain type
    public Domain() {
        values = new ArrayList<>();
        it = new DomainIterator();
    }


    public Domain(int... V) {
        this();
        for (int v : V) {
            values.add(new Value(String.valueOf(v), v));
        }
    }

    public Domain(Value... V) {
        this();
        values.addAll(Arrays.asList(V));
    }
//for jobshop problem, there are lower bound and upper bound
    public Domain(int lb, int ub) {
        this();
        for (int i = lb; i < ub; i++) {
            values.add(new Value(String.valueOf(i), i));
        }
    }

    public Domain(String... V) {
        this();
        for (int i = 0; i < V.length; i++) {
            values.add(new Value(V[i], i));
        }
    }


    public void reset() {
        it = new DomainIterator();
    }

    @Override
    public Iterator<Value> iterator() {
        return it;
    }

}
