package Variable;

import java.util.Iterator;

public class Variable {
//the variable class for the csp framework
    private String name;
    private Domain domain;
    private Value instantiation;
    private Iterator<Value> domainIt;

// different constructors of variable type

    public Variable(String name, Domain domain) {
        this.domain = domain;
        this.name = name;
        domainIt = domain.iterator();
    }

    public Variable(String name) {
        this.name = name;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
        domainIt = domain.iterator();
    }


    public boolean assign() {
        if (!domainIt.hasNext())
            return false;
        instantiation = domainIt.next();
        return true;
    }

    public void undoAssignment() {
        instantiation = null;
        domain.reset();
        domainIt = domain.iterator();
    }

    public boolean canBeAssignment() {
        return domainIt.hasNext();
    }

// get for both string and number values
    public int getValue() {
        if (isAssignment())
            return instantiation.value;
        return Integer.MAX_VALUE;
    }

    public String getValueName() {
        if (isAssignment())
            return instantiation.name;
        return null;
    }

    public String getName() {
        return name;
    }

    public boolean isAssignment() {
        return instantiation != null;
    }

    @Override
    public String toString() {
        return name + " " + instantiation;
    }
}





